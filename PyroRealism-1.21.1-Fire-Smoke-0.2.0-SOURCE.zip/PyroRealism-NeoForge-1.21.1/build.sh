#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v java >/dev/null 2>&1; then
  echo "JDK 21 is required" >&2; exit 1
fi
java -version 2>&1 | grep -q '21\.' || { echo "JDK 21 is required" >&2; exit 1; }
gradle --no-daemon clean build
