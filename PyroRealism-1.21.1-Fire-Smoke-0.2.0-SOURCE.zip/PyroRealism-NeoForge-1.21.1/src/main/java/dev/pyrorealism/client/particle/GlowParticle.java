package dev.pyrorealism.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;

/** Soft emissive amber halo. This is a visual glow, not a change to Minecraft's block-light map. */
public final class GlowParticle extends TextureSheetParticle {
    private final SpriteSet sprites;
    private final float size;
    private final boolean soul;

    public GlowParticle(ClientLevel level, double x, double y, double z,
                        double xs, double ys, double zs, SpriteSet sprites, boolean soul) {
        super(level, x, y, z, xs, ys, zs);
        this.sprites = sprites;
        this.soul = soul;
        this.size = 0.78F + this.random.nextFloat() * 0.36F;
        this.quadSize = size;
        this.lifetime = 12 + this.random.nextInt(9);
        this.hasPhysics = false;
        this.xd = xs;
        this.yd = ys;
        this.zd = zs;
        this.alpha = 0.22F;
        this.setColor(soul ? 0.22F : 1.0F, soul ? 0.88F : 0.48F, soul ? 1.0F : 0.12F);
        this.setSpriteFromAge(sprites);
    }

    @Override
    public void tick() {
        this.xo = this.x; this.yo = this.y; this.zo = this.z;
        if (this.age++ >= this.lifetime) { this.remove(); return; }
        float p = this.age / (float)this.lifetime;
        this.quadSize = size * (0.92F + p * 0.22F);
        this.alpha = 0.22F * (1.0F - p) * (0.9F + 0.1F * (float)Math.sin(this.age * 0.8));
        this.setSpriteFromAge(sprites);
    }

    @Override
    public ParticleRenderType getRenderType() { return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT; }
    @Override
    public int getLightColor(float partialTick) { return 0x00F000F0; }

    public static final class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;
        private final boolean soul;
        public Provider(SpriteSet sprites, boolean soul) { this.sprites = sprites; this.soul = soul; }
        @Override
        public GlowParticle createParticle(SimpleParticleType type, ClientLevel level,
                                           double x, double y, double z,
                                           double xs, double ys, double zs) {
            return new GlowParticle(level, x, y, z, xs, ys, zs, sprites, soul);
        }
    }
}
