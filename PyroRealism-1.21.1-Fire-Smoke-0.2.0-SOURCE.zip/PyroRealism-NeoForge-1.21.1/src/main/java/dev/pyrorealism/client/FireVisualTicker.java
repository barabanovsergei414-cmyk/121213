package dev.pyrorealism.client;

import dev.pyrorealism.PyroRealism;
import dev.pyrorealism.registry.PyroParticles;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CampfireBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

@EventBusSubscriber(modid = PyroRealism.MOD_ID, value = Dist.CLIENT)
public final class FireVisualTicker {
    private static int tickCounter;

    private FireVisualTicker() {}

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null || minecraft.player == null || minecraft.isPaused()) {
            return;
        }
        // One plume update every four ticks. Particles live long enough to overlap into a continuous column.
        if (++tickCounter % 4 != 0) {
            return;
        }

        var level = minecraft.level;
        BlockPos center = minecraft.player.blockPosition();
        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
        int processed = 0;
        final int maxSourcesPerPass = 12;
        final int radius = 9;

        scan:
        for (int dy = -3; dy <= 6; dy++) {
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    cursor.set(center.getX() + dx, center.getY() + dy, center.getZ() + dz);
                    BlockState state = level.getBlockState(cursor);
                    boolean normalFire = state.is(Blocks.FIRE);
                    boolean soulFire = state.is(Blocks.SOUL_FIRE) || state.is(Blocks.SOUL_CAMPFIRE);
                    boolean campfire = (state.is(Blocks.CAMPFIRE) || state.is(Blocks.SOUL_CAMPFIRE))
                            && state.hasProperty(CampfireBlock.LIT) && state.getValue(CampfireBlock.LIT);
                    if (!normalFire && !soulFire && !campfire) {
                        continue;
                    }
                    if (++processed > maxSourcesPerPass) {
                        break scan;
                    }
                    spawnAt(level, cursor, soulFire, campfire);
                }
            }
        }
    }

    private static void spawnAt(net.minecraft.client.multiplayer.ClientLevel level, BlockPos pos,
                                boolean soulFire, boolean campfire) {
        var random = level.random;
        // Keep the emission column close to the source. A little jitter prevents a perfectly rigid tube.
        double spread = campfire ? 0.055 : 0.075;
        double x = pos.getX() + 0.5 + (random.nextDouble() - 0.5) * spread;
        double z = pos.getZ() + 0.5 + (random.nextDouble() - 0.5) * spread;
        double baseY = pos.getY() + (campfire ? 0.66 : 0.12);
        double windX = (random.nextDouble() - 0.5) * 0.0018;
        double windZ = (random.nextDouble() - 0.5) * 0.0018;

        if (!campfire && random.nextFloat() < (soulFire ? 0.58F : 0.72F)) {
            level.addParticle(soulFire ? PyroParticles.SOUL_FLAME.get() : PyroParticles.FLAME.get(), x, baseY, z,
                    windX, 0.010 + random.nextDouble() * 0.012, windZ);
        }

        // A single dark-to-gray particle stream forms the main plume; it does not spawn parallel columns.
        level.addParticle(PyroParticles.DARK_SMOKE.get(), x, baseY + (campfire ? 0.08 : 0.02), z,
                windX, 0.010 + random.nextDouble() * 0.008, windZ);

        // Very occasional pale wisps soften the plume edges without making separate round smoke stacks.
        if (random.nextFloat() < (campfire ? 0.16F : 0.10F)) {
            level.addParticle(PyroParticles.SMOKE.get(), x + windX * 2.0, baseY + 0.08, z + windZ * 2.0,
                    windX * 0.7, 0.012 + random.nextDouble() * 0.008, windZ * 0.7);
        }

        if (!campfire && random.nextFloat() < (soulFire ? 0.13F : 0.09F)) {
            level.addParticle(PyroParticles.EMBER.get(), x, baseY, z,
                    windX * 2.0, 0.018 + random.nextDouble() * 0.025, windZ * 2.0);
        }

        // A soft emissive halo gives the flame a warm local glow. Vanilla block light remains unchanged.
        if (random.nextFloat() < 0.30F) {
            level.addParticle(soulFire ? PyroParticles.SOUL_GLOW.get() : PyroParticles.GLOW.get(), x, baseY + 0.12, z,
                    0.0, 0.0, 0.0);
        }
    }
}
